# Robyn Admin

A simple yet powerful admin interface for Robyn framework.

orm use Tortoise ORM

read more info in [en_doc](https://qc-robyn-admin.readthedocs.io/en/latest/en/)


## Installation

You can install robyn-admin via pip:

```
bash
pip install qc_robyn_admin

pip install git+https://github.com/0x7eQiChen/qc_robyn_admin.git
```

